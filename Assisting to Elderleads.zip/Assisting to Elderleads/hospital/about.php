<!DOCTYPE html>
<html lang="en">
<head><title>about us</title>
<style>
* {
  box-sizing: border-box;
}


body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}


.header {
  padding: 40px;
  text-align: center;
  background: #4baf9b;
  color: white;
}


.header h1 {
  font-size: 30px;
}


.navbar {
  overflow: hidden;
  background-color: #333;
}


.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}


.navbar a.right {
  float: right;
}


.navbar a:hover {
  background-color: #ddd;
  color: black;
}

.row {  
  display: -ms-flexbox; 
  display: flex;
  -ms-flex-wrap: wrap; 
  flex-wrap: wrap;
}


.side {
  -ms-flex: 20%; 
  flex: 20%;
  background-color: #f1f1f1;
  padding: 10px;
}


.main {   
  -ms-flex: 70%; 
  flex: 70%;
  background-color: white;
  padding: 20px;
}


.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}


.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}


@media screen and (max-width: 400px) {
  .row {   
    flex-direction: column;
  }
}


@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}
</style>
</head>
<body>

<div class="header">
  <h1>Assisting to Elderleads</h1>
 </div>



<div class="row">
  <div class="side">
    <h1>About our website</h1><br>
    <div class="img"><img src="https://cdn.searchenginejournal.com/wp-content/uploads/2015/04/Depositphotos_59977559_m-2015-760x400.jpg" width="250" height="200"></div>
  </div>
  <div class="main">
<h3>    <p>   The website is used to provide care to elder one’s by assisting them on their day by day work.<br>
	<br>
It provide home elder care health services, to educate and train nurses and caregivers in caring the older persons, and to collaborate and support eldercare technological research and development. 
<br>
 <br>It provides health-care services to these patients who have mobility problems. We treat patients holistically. We review patient’s needs, families and caregivers concerns and formulate a long–term care plan.<br>

  </div>
  
</div>

<div class="footer">
  <h3>THANKS FOR VISITING!!!</h3>
</div>

</body>
</html>
